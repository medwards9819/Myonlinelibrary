<?php
$catalog = [];


*/Books*

$catalog[101] = [
    "title" => "Harry Potter and the Deathly Hallows",
    "img" => "img/media/hayyr.jpg",
   "genre" => "Fantasy",
   "format" => "Paperback",
   "year" => 2007,
   "category" => "Books",
   "authors" => [
       "J.K Rowling",
   ],
   "publisher" => "Scholastic",
   "isbn" => '0-545-01022-5'
];

*//Movies*
$catalog[201] = [
   "title" => "Howls Moving Castle",
   "img" => "img/media/howls.jpg",
   "genre" => "Fantasy",
   "format" => "DVD",
   "year" => 2004,
   "category" => "Movies",
   "director" => "Hayao Miyazaki",
   "writers" => [
       "Hiyao Miyazaki"

   ],
   "stars" => [
       	"Chieko Baisho",
        "Takuya Kimura",
        "Akihiro Miwa"
   ]
];

*//Music*
$catalog[301] = [
   "title" => "OO",
   "img" => "img/media/zion.png",
   "genre" => "Kpop",
   "format" => "CD",
   "year" => 2017,
   "category" => "Music",
   "artist" => "Zion.T"
];

*/Books*
$catalog[101] = [
    "title" => "Crank",
    "img" => "img/media/crank.jpg",
   "genre" => "Young Adult",
   "format" => "Paperback",
   "year" => 2004,
   "category" => "Books",
   "authors" => [
       "Ellen Hopkins"
   ],
   "publisher" => "Simon and Schuster",
   "isbn" => '0-689-86519-8'
];

*//Movies*
$catalog[201] = [
   "title" => "Shrek",
   "img" => "img/media/shreck.jpg",
   "genre" => "Fantasy",
   "format" => "DVD",
   "year" => 2001,
   "category" => "Movies",
   "director" => "Andrew Adamnson", "Vicky Jenson"
    
   "writers" => [
       "Ted Elliot",
       "Terry Rossio"'
       "Joe"

   ],
   "stars" => [
       "Sam Worthington",
       "Zoe Saldana",
       "Sigourney Weaver"
   ]
];

*//Music*
$catalog[301] = [
   "title" => "Beethoven: Complete Symphonies",
   "img" => "img/media/beethoven.jpg",
   "genre" => "Clasical",
   "format" => "CD",
   "year" => 2012,
   "category" => "Music",
   "artist" => "Ludwig van Beethoven"
];






?>